const {Pool}=require('pg');
const pool=new Pool({connectionString:process.env.DATABASE_URL,ssl:process.env.DATABASE_URL&&process.env.DATABASE_URL.includes('railway')?{rejectUnauthorized:false}:undefined});
module.exports=pool;
