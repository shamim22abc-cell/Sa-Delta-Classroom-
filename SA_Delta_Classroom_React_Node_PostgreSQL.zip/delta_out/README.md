# SA Delta Classroom — React + Node.js + PostgreSQL

Converted full-stack starter based on the supplied PHP/MySQL SA Delta Question Bank.

## Included
- React/Vite admin UI
- Node.js + Express REST API
- PostgreSQL schema and automatic initialization
- Admin login + password change API
- Question CRUD, search/filter/pagination
- Bulk JSON import API
- Question selection and saved paper generation
- 11×17 browser print layout
- CSV/JSON question export
- Railway-ready `railway.json`

## Local run
1. Install Node.js 20+.
2. Create PostgreSQL database and set `DATABASE_URL`.
3. Copy `.env.example` to `.env` and change secrets/password.
4. `npm install`
5. `npm --prefix frontend install`
6. `npm --prefix frontend run build`
7. `npm start`
8. Open http://localhost:3000

## Railway
Create a Railway project, add PostgreSQL, then deploy this repository. Railway supplies `DATABASE_URL` to the service. Set `JWT_SECRET`, `ADMIN_USERNAME`, and a strong `ADMIN_PASSWORD` in Variables. The build/start commands are in `railway.json`.

## GitHub
Upload the whole project folder to a repository. Do not upload `.env` or real credentials.

## Note
This is a functional React/Node/PostgreSQL reimplementation of the supplied PHP question bank. Review UI/details against your original before production use.
